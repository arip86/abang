<table class="table" style="border:1px solid #ddd">
	<thead>
		<tr>
			<th>Nama depan</th>
			<th>Nama belakang</th>
			<th>Jenis kelamin</th>
			<th>Agama </th>
			<th>Alamat</th>
		</tr>
	</thead>

	<tbody>
		<?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td> <?php echo e($s->nama_depan); ?> </td>
			<td> <?php echo e($s->nama_belakang); ?> </td>
			<td> <?php echo e($s->jenis_kelamin); ?> </td>
			<td> <?php echo e($s->agama); ?> </td>
			<td> <?php echo e($s->alamat); ?> </td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table><?php /**PATH C:\Users\Akhmad arip\laraveldatasiswa\resources\views/export/siswapdf.blade.php ENDPATH**/ ?>